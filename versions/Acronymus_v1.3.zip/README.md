## Acronymus

Translate financial and business abbreviations into plain English

## Installation

Acronymus is a Chrome Extension. It can be found in the Chrome Web Store.

## How to Use

1) Add the Chrome Extension
2) When seeing unknown financial and business abbreviations on a web page, simply click the Acronymus icon in the upper right corner
3) Translated abbreviations will be bold in the square brackets